from setuptools import setup

setup(

    name="Mi primer pre-entrega2",
    description="mi preentrega con clases",
    author="Carlos Gonzaez",
    author_email="carlos-deoz@hotmail.com",
    packages=["PreEntrega"]

)